from flask import Flask, request, jsonify, make_response
from flask_cors import CORS
from flask_restful import Resource, Api, reqparse
from service.getall import getAllToDos, createNewToDoItem, deleteToDoItemById, deleteNote, createNewNote, completeItem
from flask_apscheduler import APScheduler